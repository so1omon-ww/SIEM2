#!/usr/bin/env python3
"""
Windows SIEM Agent - сбор данных с Windows хоста
Запускается на Windows машине с правами администратора
"""

import os
import sys
import time
import json
import psutil
import socket
import subprocess
import logging
import requests
from datetime import datetime
from typing import Dict, List, Any, Optional
import winreg
import wmi

# Настройка логирования
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(levelname)s] %(name)s: %(message)s',
    datefmt='%Y-%m-%d %H:%M:%S'
)
log = logging.getLogger("windows_agent")

class WindowsAgent:
    """Агент для сбора данных Windows"""
    
    def __init__(self, server_url: str, api_key: str, host_id: str = None):
        self.server_url = server_url
        self.api_key = api_key
        self.host_id = host_id or socket.gethostname()
        self.wmi_conn = None
        
        # Инициализируем WMI соединение
        try:
            self.wmi_conn = wmi.WMI()
            log.info("WMI connection established")
        except Exception as e:
            log.warning(f"Failed to initialize WMI: {e}")
    
    def collect_processes(self) -> List[Dict[str, Any]]:
        """Сбор информации о процессах"""
        events = []
        
        try:
            for proc in psutil.process_iter(['pid', 'name', 'username', 'cmdline', 'create_time', 'cpu_percent', 'memory_info']):
                try:
                    proc_info = proc.info
                    # Собираем только новые процессы за последние 5 минут
                    if proc_info['create_time'] and (time.time() - proc_info['create_time'] < 300):
                        event = {
                            "timestamp": datetime.utcnow().isoformat() + "Z",
                            "event_type": "process.created",
                            "source": "windows_agent",
                            "host_id": self.host_id,
                            "severity": "info",
                            "details": {
                                "process": {
                                    "pid": proc_info['pid'],
                                    "name": proc_info['name'],
                                    "username": proc_info.get('username', 'unknown'),
                                    "command_line": ' '.join(proc_info.get('cmdline', [])) if proc_info.get('cmdline') else '',
                                    "created_at": datetime.fromtimestamp(proc_info['create_time']).isoformat(),
                                    "cpu_percent": proc_info.get('cpu_percent', 0),
                                    "memory_mb": round(proc_info['memory_info'].rss / (1024*1024), 2) if proc_info.get('memory_info') else 0
                                }
                            }
                        }
                        events.append(event)
                except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
                    continue
                    
        except Exception as e:
            log.error(f"Error collecting processes: {e}")
            
        return events
    
    def collect_network_connections(self) -> List[Dict[str, Any]]:
        """Сбор сетевых соединений"""
        events = []
        
        try:
            connections = psutil.net_connections(kind='inet')
            for conn in connections:
                if conn.status == psutil.CONN_ESTABLISHED:
                    event = {
                        "timestamp": datetime.utcnow().isoformat() + "Z",
                        "event_type": "network.connection",
                        "source": "windows_agent",
                        "host_id": self.host_id,
                        "severity": "info",
                        "details": {
                            "connection": {
                                "local_addr": f"{conn.laddr.ip}:{conn.laddr.port}" if conn.laddr else "unknown",
                                "remote_addr": f"{conn.raddr.ip}:{conn.raddr.port}" if conn.raddr else "unknown",
                                "status": conn.status,
                                "pid": conn.pid,
                                "family": "IPv4" if conn.family == socket.AF_INET else "IPv6"
                            }
                        }
                    }
                    events.append(event)
                    
        except Exception as e:
            log.error(f"Error collecting network connections: {e}")
            
        return events
    
    def collect_system_performance(self) -> List[Dict[str, Any]]:
        """Сбор данных производительности системы"""
        events = []
        
        try:
            # CPU usage
            cpu_percent = psutil.cpu_percent(interval=1)
            memory = psutil.virtual_memory()
            disk_io = psutil.disk_io_counters()
            net_io = psutil.net_io_counters()
            
            # Получаем использование диска в процентах
            disk_usage = psutil.disk_usage('C:')
            disk_percent = (disk_usage.used / disk_usage.total) * 100
            
            # Получаем сетевую активность (байт в секунду)
            if not hasattr(self, '_last_net_io'):
                self._last_net_io = net_io
                self._last_net_time = time.time()
                network_usage = 0
            else:
                current_time = time.time()
                time_diff = current_time - self._last_net_time
                if time_diff > 0:
                    bytes_sent_rate = (net_io.bytes_sent - self._last_net_io.bytes_sent) / time_diff
                    bytes_recv_rate = (net_io.bytes_recv - self._last_net_io.bytes_recv) / time_diff
                    # Конвертируем в МБ/с и ограничиваем до 100%
                    network_usage = min(100, (bytes_sent_rate + bytes_recv_rate) / (1024**2) * 10)
                else:
                    network_usage = 0
                self._last_net_io = net_io
                self._last_net_time = current_time
            
            event = {
                "timestamp": datetime.utcnow().isoformat() + "Z",
                "event_type": "system.performance",
                "source": "windows_agent",
                "host_id": self.host_id,
                "severity": "info",
                "details": {
                    "performance": {
                        "cpu_percent": cpu_percent,
                        "memory_percent": memory.percent,
                        "memory_available_gb": round(memory.available / (1024**3), 2),
                        "memory_total_gb": round(memory.total / (1024**3), 2),
                        "disk_percent": round(disk_percent, 2),
                        "disk_available_gb": round(disk_usage.free / (1024**3), 2),
                        "disk_total_gb": round(disk_usage.total / (1024**3), 2),
                        "network_percent": round(network_usage, 2),
                        "network_sent_mb": round(net_io.bytes_sent / (1024**2), 2) if net_io else 0,
                        "network_recv_mb": round(net_io.bytes_recv / (1024**2), 2) if net_io else 0
                    }
                }
            }
            events.append(event)
            
        except Exception as e:
            log.error(f"Error collecting performance data: {e}")
            
        return events
    
    def collect_windows_events(self) -> List[Dict[str, Any]]:
        """Сбор Windows Event Log"""
        events = []
        
        try:
            # Команда для получения событий безопасности
            ps_command = [
                'powershell', '-Command',
                "Get-WinEvent -FilterHashtable @{LogName='Security'; StartTime=(Get-Date).AddMinutes(-5)} -MaxEvents 10 -ErrorAction SilentlyContinue | ConvertTo-Json"
            ]
            
            result = subprocess.run(ps_command, capture_output=True, text=True, timeout=30)
            
            if result.returncode == 0 and result.stdout.strip():
                try:
                    win_events = json.loads(result.stdout)
                    if not isinstance(win_events, list):
                        win_events = [win_events]
                        
                    for win_event in win_events:
                        event = {
                            "timestamp": datetime.utcnow().isoformat() + "Z",
                            "event_type": "windows.security_event",
                            "source": "windows_agent",
                            "host_id": self.host_id,
                            "severity": "warning" if win_event.get('LevelDisplayName') == 'Warning' else "info",
                            "details": {
                                "windows_event": {
                                    "event_id": win_event.get('Id'),
                                    "level": win_event.get('LevelDisplayName'),
                                    "log_name": win_event.get('LogName'),
                                    "provider_name": win_event.get('ProviderName'),
                                    "message": win_event.get('Message', '')[:500]
                                }
                            }
                        }
                        events.append(event)
                except json.JSONDecodeError:
                    log.warning("Failed to parse PowerShell JSON output")
                    
        except Exception as e:
            log.debug(f"Error collecting Windows events: {e}")
            
        return events
    
    def collect_system_info(self) -> List[Dict[str, Any]]:
        """Сбор информации о системе"""
        events = []
        
        try:
            # Информация о системе через WMI
            if self.wmi_conn:
                for system in self.wmi_conn.Win32_ComputerSystem():
                    event = {
                        "timestamp": datetime.utcnow().isoformat() + "Z",
                        "event_type": "system.info",
                        "source": "windows_agent",
                        "host_id": self.host_id,
                        "severity": "info",
                        "details": {
                            "system": {
                                "manufacturer": system.Manufacturer,
                                "model": system.Model,
                                "total_physical_memory": system.TotalPhysicalMemory,
                                "number_of_processors": system.NumberOfProcessors,
                                "domain": system.Domain,
                                "workgroup": system.Workgroup
                            }
                        }
                    }
                    events.append(event)
                    break  # Берем только первую запись
                    
        except Exception as e:
            log.debug(f"Error collecting system info: {e}")
            
        return events
    
    def collect_installed_software(self) -> List[Dict[str, Any]]:
        """Сбор информации об установленном ПО"""
        events = []
        
        try:
            if self.wmi_conn:
                # Получаем список установленных программ
                for software in self.wmi_conn.Win32_Product():
                    event = {
                        "timestamp": datetime.utcnow().isoformat() + "Z",
                        "event_type": "software.installed",
                        "source": "windows_agent",
                        "host_id": self.host_id,
                        "severity": "info",
                        "details": {
                            "software": {
                                "name": software.Name,
                                "version": software.Version,
                                "vendor": software.Vendor,
                                "install_date": software.InstallDate
                            }
                        }
                    }
                    events.append(event)
                    
        except Exception as e:
            log.debug(f"Error collecting software info: {e}")
            
        return events
    
    def send_events(self, events: List[Dict[str, Any]]) -> bool:
        """Отправка событий на сервер"""
        if not events:
            return True
            
        try:
            url = f"{self.server_url}/api/events/ingest/batch"
            headers = {
                "Content-Type": "application/json",
                "X-API-Key": self.api_key
            }
            
            response = requests.post(
                url, 
                json={"items": events}, 
                headers=headers,
                timeout=10,
                verify=False
            )
            
            if response.status_code == 200:
                log.info(f"Sent {len(events)} events successfully")
                return True
            else:
                log.error(f"Failed to send events: {response.status_code} {response.text}")
                return False
                
        except Exception as e:
            log.error(f"Error sending events: {e}")
            return False

def main():
    """Основная функция Windows агента"""
    
    # Получаем конфигурацию из переменных окружения
    server_url = os.environ.get("SERVER_URL", "http://localhost:8000")
    api_key = os.environ.get("API_KEY") or os.environ.get("SIEM_API_KEY")
    host_id = os.environ.get("HOST_ID") or socket.gethostname()
    
    if not api_key:
        log.error("API_KEY not set! Please set API_KEY environment variable")
        log.error("You can get API key from web interface: http://localhost:3000/register")
        sys.exit(1)
    
    log.info("Windows Agent starting")
    log.info(f"Server: {server_url}")
    log.info(f"API key: {'***' if api_key else 'NOT SET'}")
    log.info(f"Host: {host_id}")
    log.info(f"Python: {sys.version}")
    
    # Проверяем права администратора
    try:
        is_admin = os.getuid() == 0
    except AttributeError:
        # На Windows проверяем через UAC
        try:
            import ctypes
            is_admin = ctypes.windll.shell32.IsUserAnAdmin()
        except:
            is_admin = False
    
    if not is_admin:
        log.warning("Agent is not running with administrator privileges")
        log.warning("Some features may not work properly")
    
    agent = WindowsAgent(server_url, api_key, host_id)
    
    log.info("Starting data collection...")
    
    # Счетчики для разных типов событий
    collection_cycles = 0
    
    while True:
        try:
            all_events = []
            collection_cycles += 1
            
            # Собираем разные типы событий
            log.debug("Collecting processes...")
            all_events.extend(agent.collect_processes())
            
            log.debug("Collecting network connections...")
            all_events.extend(agent.collect_network_connections())
            
            log.debug("Collecting performance data...")
            all_events.extend(agent.collect_system_performance())
            
            # Собираем Windows события каждые 5 циклов (5 минут)
            if collection_cycles % 5 == 0:
                log.debug("Collecting Windows events...")
                all_events.extend(agent.collect_windows_events())
            
            # Собираем информацию о системе каждые 10 циклов (10 минут)
            if collection_cycles % 10 == 0:
                log.debug("Collecting system info...")
                all_events.extend(agent.collect_system_info())
            
            # Собираем информацию о ПО каждые 30 циклов (30 минут)
            if collection_cycles % 30 == 0:
                log.debug("Collecting software info...")
                all_events.extend(agent.collect_installed_software())
            
            # Отправляем события
            if all_events:
                success = agent.send_events(all_events)
                if success:
                    log.info(f"Collected and sent {len(all_events)} events")
                else:
                    log.warning(f"Failed to send {len(all_events)} events")
            else:
                log.info("No new events to send")
            
            # Ждем между циклами сбора
            time.sleep(60)  # 1 минута
            
        except KeyboardInterrupt:
            log.info("Received shutdown signal")
            break
        except Exception as e:
            log.error(f"Error in main loop: {e}")
            time.sleep(10)

if __name__ == "__main__":
    main()
