# SIEM Windows Agent v2.0.0 - Офлайн Репозиторий

## Описание
Офлайн репозиторий для развертывания SIEM агента на Windows системах без доступа к интернету.

## Содержимое
- `agent/` - Исходный код агента
- `dependencies/` - Python пакеты
- `install/` - Скрипты установки
- `config/` - Конфигурационные файлы

## Требования
- Windows 10/11 или Windows Server 2016+
- Python 3.8+ (установите с https://python.org)
- Права администратора для установки

## Установка

### Автоматическая установка
1. Распакуйте архив в любую папку
2. Запустите `install\install.bat` от имени администратора
3. Настройте конфигурацию в `C:\SIEM-Agent\config\agent.yaml`
4. Запустите службу: `sc start SIEMAgent`

### Ручная установка
1. Установите Python 3.8+ с https://python.org
2. Скопируйте папку agent в C:\SIEM-Agent\
3. Установите зависимости: `pip install -r requirements.txt`
4. Настройте конфигурацию
5. Запустите агента: `python windows_agent.py`

## Конфигурация
Отредактируйте файл `C:\SIEM-Agent\config\agent.yaml`:
```yaml
server:
  url: "http://your-siem-server:8000"
  api_key: "your-api-key"

agent:
  hostname: "your-computer-name"
  collect_interval: 30
  log_level: "INFO"
```

## Управление службой
- Запуск: `sc start SIEMAgent`
- Остановка: `sc stop SIEMAgent`
- Удаление: `sc delete SIEMAgent`

## Поддерживаемые функции
- Сбор системных метрик (CPU, память, диск, сеть)
- Мониторинг процессов
- Сбор сетевых подключений
- Windows Event Log
- WMI данные

## Лицензия
Proprietary - SIEM Security System
