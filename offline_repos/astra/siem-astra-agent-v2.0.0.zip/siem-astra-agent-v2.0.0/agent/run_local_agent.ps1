# PowerShell script for running local agent with API key
$env:API_KEY = "cd3f4dcc53ea3cf6f31cf4b4e2907c84b499c0d54b2084c50575c00f8db24f58"
$env:SERVER_URL = "http://localhost:8000"

Write-Host "API_KEY set: $($env:API_KEY.Substring(0,8))..." -ForegroundColor Green
Write-Host "SERVER_URL: $env:SERVER_URL" -ForegroundColor Green
Write-Host "Starting agent..." -ForegroundColor Yellow

python agent.py
