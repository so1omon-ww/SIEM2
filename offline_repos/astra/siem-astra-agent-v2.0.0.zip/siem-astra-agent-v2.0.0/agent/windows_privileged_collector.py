#!/usr/bin/env python3
"""
Windows Privileged Collector
Сборщик данных Windows с привилегированным доступом
"""

import os
import sys
import json
import subprocess
import logging
from datetime import datetime
from typing import Dict, List, Any, Optional

log = logging.getLogger("windows_collector")

class WindowsPrivilegedCollector:
    """Сборщик данных Windows с привилегированным доступом"""
    
    def __init__(self, host_id: str):
        self.host_id = host_id
        self.powershell_available = self._check_powershell()
        
    def _check_powershell(self) -> bool:
        """Проверяет доступность PowerShell"""
        try:
            result = subprocess.run(['powershell', '-Command', 'Get-Host'], 
                                  capture_output=True, text=True, timeout=5)
            return result.returncode == 0
        except:
            return False
    
    def collect_security_events(self) -> List[Dict[str, Any]]:
        """Сбор событий безопасности Windows"""
        events = []
        
        if not self.powershell_available:
            log.debug("PowerShell not available, skipping security events")
            return events
            
        try:
            # Команда для получения событий безопасности
            ps_command = [
                'powershell', '-Command',
                "Get-WinEvent -FilterHashtable @{LogName='Security'; StartTime=(Get-Date).AddMinutes(-5)} -MaxEvents 10 -ErrorAction SilentlyContinue | ConvertTo-Json"
            ]
            
            result = subprocess.run(ps_command, capture_output=True, text=True, timeout=30)
            
            if result.returncode == 0 and result.stdout.strip():
                try:
                    win_events = json.loads(result.stdout)
                    if not isinstance(win_events, list):
                        win_events = [win_events]
                        
                    for win_event in win_events:
                        event = {
                            "timestamp": datetime.utcnow().isoformat() + "Z",
                            "event_type": "windows.security_event",
                            "source": "windows_privileged_collector",
                            "host_id": self.host_id,
                            "severity": "warning" if win_event.get('LevelDisplayName') == 'Warning' else "info",
                            "details": {
                                "windows_event": {
                                    "event_id": win_event.get('Id'),
                                    "level": win_event.get('LevelDisplayName'),
                                    "log_name": win_event.get('LogName'),
                                    "provider_name": win_event.get('ProviderName'),
                                    "message": win_event.get('Message', '')[:500]
                                }
                            }
                        }
                        events.append(event)
                except json.JSONDecodeError:
                    log.warning("Failed to parse PowerShell JSON output")
                    
        except Exception as e:
            log.debug(f"Error collecting security events: {e}")
            
        return events
    
    def collect_system_events(self) -> List[Dict[str, Any]]:
        """Сбор системных событий Windows"""
        events = []
        
        if not self.powershell_available:
            log.debug("PowerShell not available, skipping system events")
            return events
            
        try:
            # Команда для получения системных событий
            ps_command = [
                'powershell', '-Command',
                "Get-WinEvent -FilterHashtable @{LogName='System'; StartTime=(Get-Date).AddMinutes(-5)} -MaxEvents 5 -ErrorAction SilentlyContinue | ConvertTo-Json"
            ]
            
            result = subprocess.run(ps_command, capture_output=True, text=True, timeout=30)
            
            if result.returncode == 0 and result.stdout.strip():
                try:
                    win_events = json.loads(result.stdout)
                    if not isinstance(win_events, list):
                        win_events = [win_events]
                        
                    for win_event in win_events:
                        event = {
                            "timestamp": datetime.utcnow().isoformat() + "Z",
                            "event_type": "windows.system_event",
                            "source": "windows_privileged_collector",
                            "host_id": self.host_id,
                            "severity": "error" if win_event.get('LevelDisplayName') == 'Error' else "info",
                            "details": {
                                "windows_event": {
                                    "event_id": win_event.get('Id'),
                                    "level": win_event.get('LevelDisplayName'),
                                    "log_name": win_event.get('LogName'),
                                    "provider_name": win_event.get('ProviderName'),
                                    "message": win_event.get('Message', '')[:500]
                                }
                            }
                        }
                        events.append(event)
                except json.JSONDecodeError:
                    log.warning("Failed to parse PowerShell JSON output")
                    
        except Exception as e:
            log.debug(f"Error collecting system events: {e}")
            
        return events
    
    def collect_process_creation_events(self) -> List[Dict[str, Any]]:
        """Сбор событий создания процессов через WMI"""
        events = []
        
        if not self.powershell_available:
            log.debug("PowerShell not available, skipping process events")
            return events
            
        try:
            # Команда для получения событий создания процессов
            ps_command = [
                'powershell', '-Command',
                "Get-WinEvent -FilterHashtable @{LogName='Security'; ID=4688; StartTime=(Get-Date).AddMinutes(-5)} -MaxEvents 5 -ErrorAction SilentlyContinue | ConvertTo-Json"
            ]
            
            result = subprocess.run(ps_command, capture_output=True, text=True, timeout=30)
            
            if result.returncode == 0 and result.stdout.strip():
                try:
                    win_events = json.loads(result.stdout)
                    if not isinstance(win_events, list):
                        win_events = [win_events]
                        
                    for win_event in win_events:
                        event = {
                            "timestamp": datetime.utcnow().isoformat() + "Z",
                            "event_type": "windows.process_creation",
                            "source": "windows_privileged_collector",
                            "host_id": self.host_id,
                            "severity": "info",
                            "details": {
                                "windows_event": {
                                    "event_id": win_event.get('Id'),
                                    "log_name": win_event.get('LogName'),
                                    "message": win_event.get('Message', '')[:500]
                                }
                            }
                        }
                        events.append(event)
                except json.JSONDecodeError:
                    log.warning("Failed to parse PowerShell JSON output")
                    
        except Exception as e:
            log.debug(f"Error collecting process creation events: {e}")
            
        return events
    
    def collect_network_activity(self) -> List[Dict[str, Any]]:
        """Сбор сетевой активности Windows"""
        events = []
        
        if not self.powershell_available:
            log.debug("PowerShell not available, skipping network activity")
            return events
            
        try:
            # Команда для получения сетевых соединений
            ps_command = [
                'powershell', '-Command',
                "Get-NetTCPConnection | Where-Object {$_.State -eq 'Established'} | Select-Object LocalAddress,LocalPort,RemoteAddress,RemotePort,State,OwningProcess | ConvertTo-Json"
            ]
            
            result = subprocess.run(ps_command, capture_output=True, text=True, timeout=30)
            
            if result.returncode == 0 and result.stdout.strip():
                try:
                    connections = json.loads(result.stdout)
                    if not isinstance(connections, list):
                        connections = [connections]
                        
                    for conn in connections:
                        event = {
                            "timestamp": datetime.utcnow().isoformat() + "Z",
                            "event_type": "windows.network_connection",
                            "source": "windows_privileged_collector",
                            "host_id": self.host_id,
                            "severity": "info",
                            "details": {
                                "connection": {
                                    "local_address": conn.get('LocalAddress'),
                                    "local_port": conn.get('LocalPort'),
                                    "remote_address": conn.get('RemoteAddress'),
                                    "remote_port": conn.get('RemotePort'),
                                    "state": conn.get('State'),
                                    "process_id": conn.get('OwningProcess')
                                }
                            }
                        }
                        events.append(event)
                except json.JSONDecodeError:
                    log.warning("Failed to parse PowerShell JSON output")
                    
        except Exception as e:
            log.debug(f"Error collecting network activity: {e}")
            
        return events