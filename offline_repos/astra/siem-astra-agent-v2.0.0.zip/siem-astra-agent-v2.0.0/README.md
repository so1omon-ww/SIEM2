# SIEM Astra Linux Agent v2.0.0 - Офлайн Репозиторий для Astra Linux 1.7

## Описание
Офлайн репозиторий для развертывания SIEM агента на Astra Linux 1.7 системах без доступа к интернету.

## Совместимость
- ✅ Astra Linux 1.7 (Python 3.7.3)
- ✅ Python 3.7+
- ✅ systemd
- ✅ Полностью офлайн установка

## Содержимое
- `agent/` - Исходный код агента
- `packages/` - Python пакеты для Python 3.7
- `install/` - Скрипты установки
- `config/` - Конфигурационные файлы

## Требования
- Astra Linux 1.7
- Python 3.7+ (включен в Astra Linux 1.7)
- Root права для установки

## Установка

### Автоматическая установка
1. Распакуйте архив в любую папку
2. Запустите `sudo ./install/install.sh`
3. Настройте конфигурацию в `/opt/siem-agent/config/agent.yaml`
4. Служба запустится автоматически

### Ручная установка
1. Установите системные пакеты:
   ```bash
   sudo apt-get update
   sudo apt-get install python3-pip python3-setuptools python3-wheel
   ```

2. Скопируйте папку agent в /opt/siem-agent/
3. Установите зависимости:
   ```bash
   cd /opt/siem-agent/agent
   pip3 install -r requirements_astra_1.7.txt
   ```
4. Настройте конфигурацию
5. Запустите агента: `python3 windows_agent.py`

## Конфигурация
Отредактируйте файл `/opt/siem-agent/config/agent.yaml`:
```yaml
server:
  url: "http://your-siem-server:8000"
  api_key: "your-api-key"

agent:
  hostname: "your-computer-name"
  collect_interval: 30
  log_level: "INFO"
```

## Управление службой
- Запуск: `sudo systemctl start siem-agent`
- Остановка: `sudo systemctl stop siem-agent`
- Статус: `sudo systemctl status siem-agent`
- Логи: `sudo journalctl -u siem-agent -f`

## Поддерживаемые функции
- Сбор системных метрик (CPU, память, диск, сеть)
- Мониторинг процессов
- Сбор сетевых подключений
- Системные логи

## Особенности для Astra Linux 1.7
- Использует Python 3.7 совместимые версии пакетов
- Проверяет версию Python перед установкой
- Оптимизирован для Astra Linux 1.7

## Лицензия
Proprietary - SIEM Security System
